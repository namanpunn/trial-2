<!-- footer styles -->

<style>.u-footer .u-sheet-1 {
  min-height: 367px;
}
.u-footer .u-layout-wrap-1 {
  margin: 60px auto 0 0;
}
.u-footer .u-layout-cell-1 {
  background-image: none;
  min-height: 131px;
}
.u-footer .u-container-layout-1 {
  padding: 20px 30px;
}
.u-footer .u-layout-cell-2 {
  min-height: 131px;
}
.u-footer .u-container-layout-2 {
  padding: 20px 30px;
}
.u-footer .u-layout-cell-3 {
  min-height: 169px;
}
.u-footer .u-container-layout-3 {
  padding: 20px 29px;
}
.u-footer .u-position-3 {
  height: auto;
  min-height: 49px;
  width: 300px;
  margin: 0 auto;
}
.u-footer .u-line-1 {
  transform-origin: right center 0px;
  width: 1140px;
  margin: 30px auto 0 0;
}
.u-footer .u-social-icons-1 {
  white-space: nowrap;
  height: 47px;
  min-height: 16px;
  width: 217px;
  min-width: 94px;
  margin: 20px 58px 0 auto;
}
.u-footer .u-icon-1 {
  color: rgb(59, 89, 152) !important;
}
.u-footer .u-icon-2 {
  color: rgb(85, 172, 238) !important;
}
.u-footer .u-icon-3 {
  color: rgb(197, 54, 164) !important;
}
.u-footer .u-icon-4 {
  color: rgb(203, 32, 39) !important;
}
.u-footer .u-image-1 {
  width: 58px;
  height: 58px;
  margin: -47px auto 60px 26px;
}
.u-footer .u-logo-image-1 {
  width: 100%;
  height: 100%;
}
@media (max-width: 1199px) {
  .u-footer .u-sheet-1 {
    min-height: 305px;
  }
  .u-footer .u-layout-wrap-1 {
    margin-right: initial;
    margin-left: initial;
  }
  .u-footer .u-container-layout-1 {
    padding-left: 25px;
    padding-right: 25px;
  }
  .u-footer .u-layout-cell-3 {
    min-height: 131px;
  }
  .u-footer .u-position-3 {
    width: 235px;
  }
  .u-footer .u-line-1 {
    margin-right: initial;
    margin-left: initial;
    width: auto;
  }
  .u-footer .u-social-icons-1 {
    width: 143px;
    min-width: 120px;
    margin-right: 17px;
  }
  .u-footer .u-image-1 {
    margin-top: -21px;
    margin-left: 21px;
  }
}
@media (max-width: 991px) {
  .u-footer .u-container-layout-1 {
    padding-left: 30px;
    padding-right: 30px;
  }
  .u-footer .u-social-icons-1 {
    margin-right: 13px;
  }
  .u-footer .u-image-1 {
    margin-left: 16px;
  }
}
@media (max-width: 767px) {
  .u-footer .u-container-layout-1 {
    padding-left: 10px;
    padding-right: 10px;
  }
  .u-footer .u-layout-cell-2 {
    min-height: auto;
  }
  .u-footer .u-container-layout-2 {
    padding-left: 10px;
    padding-right: 10px;
  }
  .u-footer .u-layout-cell-3 {
    min-height: auto;
  }
  .u-footer .u-container-layout-3 {
    padding-left: 10px;
    padding-right: 10px;
  }
  .u-footer .u-social-icons-1 {
    margin-right: 10px;
  }
  .u-footer .u-image-1 {
    margin-left: 12px;
  }
}
@media (max-width: 575px) {
  .u-footer .u-social-icons-1 {
    margin-right: 6px;
  }
  .u-footer .u-image-1 {
    margin-left: 8px;
  }
}</style>
